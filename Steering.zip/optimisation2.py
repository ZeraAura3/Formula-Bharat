﻿import numpy as np
from scipy.optimize import fsolve
from math import sin, cos, radians
from matplotlib import pyplot as plt

# Define input range for parametric change
change = np.arange(0, 1, 0.1)

# Output lists for plotting
tie_rod = []
rack_travel = []
distance = []
i_values = []

# Fixed geometry parameters
t_d = 20 * 0.0254  # Track width in meters (20 inches)
t_w = 8 * 0.0254   # Wheelbase offset in meters (8 inches)
tr = 3             # Turning radius
L = 1.550          # Wheelbase in meters
W = 1.250          # Track width in meters
beta = radians(20.457)  # Steering inclination angle in radians
p = 0.428          # Length of rack casing (m)
r = 0.031          # Rack ball joint radius (m)
steering_arm = 0.114  # Length of steering arm (m)
B = 1.119          # Front axle width (m)

# Loop over change parameter
for i in change:
    # Adjust inner/outer steering angles based on turning radius
    del_i = L / (tr - W / 2)
    del_o = L / (tr + W / 2)

    # Define the system of nonlinear equations
    def equations(vars):
        y, q, d = vars
        eq1 = y**2 - ((B/2 - (p/2 + r - q) - steering_arm * sin(del_i + beta))**2 +
                      (d - steering_arm * cos(del_i + beta))**2)
        eq2 = y**2 - ((B/2 - (p/2 + r + q) + steering_arm * sin(del_o - beta))**2 +
                      (d - steering_arm * cos(del_o - beta))**2)
        eq3 = y**2 - ((B/2 - p/2 - r - steering_arm * sin(beta))**2 +
                      (d - steering_arm * cos(beta))**2)
        return [eq1, eq2, eq3]

    # Initial guess for [tie rod length, rack travel, rack distance]
    initial_guess = [0.5, 0.1, 0.5]

    # Solve using fsolve with error handling
    solution, info, ier, msg = fsolve(equations, initial_guess, full_output=True)
    if ier != 1:
        print(f"⚠️ Convergence failed at i = {i:.2f}: {msg}")
        continue

    y, q, d = solution
    print(f"[i = {i:.2f}] y = {y:.4f} m, q = {q:.4f} m, d = {d:.4f} m")

    # Store results
    tie_rod.append(y)
    rack_travel.append(q)
    distance.append(d)
    i_values.append(i)

# Plotting
plt.figure(figsize=(10, 6))
plt.plot(i_values, tie_rod, marker='o', label='Tie rod length (m)')
plt.plot(i_values, rack_travel, marker='s', label='Rack travel distance (m)')
plt.plot(i_values, distance, marker='^', label='Rack axis offset (m)')
plt.xlabel('Change Parameter')
plt.ylabel('Length (meters)')
plt.title('Steering Geometry Optimization')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
