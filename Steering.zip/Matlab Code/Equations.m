clc
clear all
% Ensure gamma is in radians
% gamma = deg2rad(gamma); % Uncomment this if input is in degrees
l1 = 100;
gamma = deg2rad(65); % If input is in degrees
h = 90;
k = 1585;
m = 355.6;
s = 50;
W = 1585;
L = 1725;
% Step 1: Calculate l2
term1 = (k/2 -m/2 - l1 * cos(gamma))^2;
term2 = (h-l1 * sin(gamma))^2;
l2 = sqrt(term1 + term2);
disp(l2)
% Step 2: Compute for inner
A = (k/2 - m/2 + s);
B = sqrt(h^2 + (k/2 - m/2 + s)^2);
numerator = (l1^2 + B^2 - l2^2);
denominator = 2 * l1 * B;
acos_term = acos(numerator / denominator);
atan_term = atan(h / A);

% Step 2: Compute for outer
A2 = (k/2 - m/2 - s);
B2 = sqrt(h^2 + (k/2 - m/2 - s)^2);
numerator2 = (l1^2 + h^2 + A2^2 - l2^2);
denominator2 = 2 * l1 * B2;
acos_term2 = acos(numerator2 / denominator2);
atan_term2 = atan(h / A2);

% Step 3: Compute inner and outer angles
outer_angle = atan_term2 + acos_term2 - gamma;
inner_angle = -atan_term - acos_term + gamma;

% Step 4: Compute cotangent of both angles
cot_outer_angle = cot(outer_angle);
cot_inner_angle = cot(inner_angle);
disp(['l2 = ', num2str(l2, '%.4f')]);                             % l2 value
disp(['Outer Angle (deg) = ', num2str(rad2deg(outer_angle), '%.4f')]); % outer angle in degrees
disp(['Inner Angle (deg) = ', num2str(rad2deg(inner_angle ), '%.4f')]); % inner angle in degrees

fprintf('Cot(Inner Angle): %.4f\n', cot_inner_angle);
fprintf('Cot(Outer Angle): %.4f\n', cot_outer_angle);
fprintf('cot(Outer) - cot(Inner): %.4f\n', cot_outer_angle - cot_inner_angle);
fprintf('W / L: %.4f\n', W / L);


