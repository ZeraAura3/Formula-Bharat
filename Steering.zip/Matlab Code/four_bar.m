clc;
clear;

% Constants
l = 1725;   % Wheelbase
w = 1585;   % Track width
beta = 24.675 * pi / 180;  % Convert beta to radians

% Steering arm length range
steering_arm = 50:40:1000;    

% Inner wheel angles in degrees and radians
inner_angle_deg = 0.1:0.5:40;     % Inner wheel angle in degrees
inner_angle_rad = deg2rad(inner_angle_deg);

% Ackermann ideal outer angle
ackerman_out = acotd((w/l) + cotd(inner_angle_deg));  % Pure Ackermann

% Pre-allocate error array
total_error = zeros(size(steering_arm));

% Plot Ackermann reference
figure;
plot(inner_angle_deg, ackerman_out, 'k', 'LineWidth', 2);
hold on;

% Loop over steering arm lengths
for j = 1:length(steering_arm)
    d = steering_arm(j);
    a_out_deg = zeros(size(inner_angle_deg));
    
    syms a_out real
    for i = 1:length(inner_angle_rad)
        in_angle = inner_angle_rad(i);
        eq = (w - 2*d*sin(beta))^2 == ...
             (w - d*sin(beta + in_angle) - d*sin(beta - a_out))^2 + ...
             (d*cos(beta - a_out) - d*cos(beta + in_angle))^2;
        sol = vpasolve(eq, a_out, [0 pi/2]);  % Limit solution range
        if isempty(sol)
            a_out_deg(i) = NaN;
        else
            a_out_deg(i) = double(rad2deg(sol));
        end
    end

    % Store error from Ackermann
    total_error(j) = nansum((a_out_deg - ackerman_out).^2);

    % Plot the curve for this steering arm
    plot(inner_angle_deg, a_out_deg, 'DisplayName', sprintf('d = %d mm', d));
end

% Find optimal d
[~, idx_min] = min(total_error);
best_d = steering_arm(idx_min);

% Plot optimal d separately
% Recalculate for best_d
d = best_d;
a_out_deg_best = zeros(size(inner_angle_deg));
syms a_out real
for i = 1:length(inner_angle_rad)
    in_angle = inner_angle_rad(i);
    eq = (w - 2*d*sin(beta))^2 == ...
         (w - d*sin(beta + in_angle) - d*sin(beta - a_out))^2 + ...
         (d*cos(beta - a_out) - d*cos(beta + in_angle))^2;
    sol = vpasolve(eq, a_out, [0 pi/2]);
    if isempty(sol)
        a_out_deg_best(i) = NaN;
    else
        a_out_deg_best(i) = double(rad2deg(sol));
    end
end

plot(inner_angle_deg, a_out_deg_best, 'r', 'LineWidth', 2, ...
     'DisplayName', sprintf('Optimal d = %d mm', best_d));

% Final plot setup
title("Outer Wheel Angle vs Inner Wheel Angle for Various Steering Arm Lengths");
xlabel("Inner Wheel Angle (degrees)");
ylabel("Outer Wheel Angle (degrees)");
legend('Location', 'best');
grid on;
hold off;

fprintf('Optimal steering arm length (d) = %.2f mm\n', best_d);
