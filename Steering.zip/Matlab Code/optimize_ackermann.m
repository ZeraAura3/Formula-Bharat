clc;
clear;

% === Constants ===
m = 355.6;       % Distance between rack endpoints [mm]
k = 1585;        % Track width [mm]
W = 1585;        % Track width for ideal angle [mm]
L = 1725;        % Wheelbase [mm]

% === Range of inner angles (degrees) ===
inner_angles_deg = 0:1:47;
inner_angle_rad = deg2rad(inner_angles_deg);  % Convert to radians

% === Objective function over all inner angles ===
obj = @(x) ackermann_objective(x, inner_angle_rad, k, m);

% === Initial guess and bounds [gamma (rad), l1 (mm), h (mm)] ===
x0 = [deg2rad(70), 100, 90];
lb = [deg2rad(65), 52, 50];
ub = [deg2rad(75), 145, 130];

% === Optimization ===
options = optimoptions('fmincon','Display','iter');
[opt_x, fval] = fmincon(obj, x0, [], [], [], [], lb, ub, [], options);

% === Display optimized parameters ===
fprintf('\nOptimized Geometry Parameters:\n');
fprintf('Gamma (deg): %.2f\n', rad2deg(opt_x(1)));
fprintf('l1 (mm):      %.2f\n', opt_x(2));
fprintf('h (mm):       %.2f\n', opt_x(3));
fprintf('Mean Squared Error: %.6f\n', fval);

% === Use optimized geometry to calculate outer angles ===
gamma = opt_x(1);  % radians
l1 = opt_x(2);     % mm
h = opt_x(3);      % mm

outer_angles_deg = zeros(size(inner_angle_rad));
ideal_outer_angle = zeros(size(inner_angle_rad));

% Compute l2 based on geometry
term1 = (k/2 - m/2 - l1 * cos(gamma))^2;
term2 = (h - l1 * sin(gamma))^2;
l2 = sqrt(term1 + term2);

for i = 1:length(inner_angle_rad)
    ia = inner_angle_rad(i);

    fun = @(s) -atan(h / (k/2 - m/2 + s)) - ...
        acos(min(max((l1^2 + h^2 + (k/2 - m/2 + s).^2 - l2^2) / ...
        (2 * l1 * sqrt(h^2 + (k/2 - m/2 + s).^2)), -1), 1)) + gamma - ia;

    try
        s = fsolve(fun, 100, optimset('Display','off'));
        if ~isreal(s) || isnan(s) || s < 0
            outer_angles_deg(i) = NaN;
            continue;
        end
    catch
        outer_angles_deg(i) = NaN;
        continue;
    end

    % Outer angle calculation
    A2 = (k/2 - m/2 - s);
    B2 = sqrt(h^2 + A2^2);
    acos_term2 = min(max((l1^2 + h^2 + A2^2 - l2^2) / (2 * l1 * B2), -1), 1);
    outer_angle_rad = atan(h / A2) + acos(acos_term2) - gamma;

    outer_angles_deg(i) = rad2deg(outer_angle_rad);

    % Ideal outer angle from Ackermann
    cot_outer = (W / L) + cot(ia);
    ideal_outer_angle(i) = rad2deg(acot(cot_outer));
end



% === Plot Inner vs Outer Angle ===
figure;
plot(inner_angles_deg, outer_angles_deg, 'b-', 'LineWidth', 2); hold on;
plot(inner_angles_deg, ideal_outer_angle, 'r--', 'LineWidth', 2);
xlabel('Inner Steering Angle (deg)');
ylabel('Outer Steering Angle (deg)');
title('Optimized Steering Geometry: Calculated vs Ideal Outer Angle');
legend('Calculated Outer Angle', 'Ideal Ackermann Angle');
grid on;
