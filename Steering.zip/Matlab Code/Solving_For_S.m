clc;
clear all;

% Constants
l1 = 100;
gamma = deg2rad(65);   % Convert gamma to radians
h = 90;
k = 1585;
m = 355.6;
W = 1585;
L = 1725;

% Step 1: Calculate l2
term1 = (k/2 - m/2 - l1 * cos(gamma))^2;
term2 = (h - l1 * sin(gamma))^2;
l2 = sqrt(term1 + term2);

% Target inner angle in radians
inner_angle_target = deg2rad(40);

% Step 2: Define function to solve for s
fun = @(s) -atan(h / (k/2 - m/2 + s)) - ...
           acos((l1^2 + h^2 + (k/2 - m/2 + s).^2 - l2^2) ./ ...
           (2 * l1 * sqrt(h^2 + (k/2 - m/2 + s).^2))) + gamma - inner_angle_target;

% Step 3: Solve for s using fsolve
s_guess = 100;  % Initial guess
options = optimset('Display','off'); % Hide fsolve output
s_solution = fsolve(fun, s_guess, options);

% Step 4: Use s to compute outer angle
A2 = (k/2 - m/2 - s_solution);
B2 = sqrt(h^2 + A2^2);
numerator2 = (l1^2 + h^2 + A2^2 - l2^2);
denominator2 = 2 * l1 * B2;
acos_term2 = acos(numerator2 / denominator2);
atan_term2 = atan(h / A2);
outer_angle = atan_term2 + acos_term2 - gamma;

cot_outer_angle = cot(outer_angle);
cot_inner_angle = cot(inner_angle_target);
fprintf('cot(Outer) - cot(Inner): %.4f\n', cot_outer_angle - cot_inner_angle);

% Display Results
fprintf('--- Results ---\n');
fprintf('Computed s = %.4f mm\n', s_solution);
fprintf('Inner Angle (deg) = %.4f° (Given)\n', rad2deg(inner_angle_target));
fprintf('Outer Angle (deg) = %.4f°\n', rad2deg(outer_angle));
fprintf('Cot(Inner Angle): %.4f\n', cot_inner_angle);
fprintf('Cot(Outer Angle): %.4f\n', cot_outer_angle);
fprintf('W / L = %.4f\n', W / L);
