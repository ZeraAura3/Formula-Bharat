function err_sum = ackermann_objective(x, inner_angle, k, m)
    gamma = x(1);      % in radians
    l1 = x(2);         % in mm
    h = x(3);          % in mm
    W = 1585;          % Track width for ideal angle [mm]
    L = 1725;          % Wheelbase [mm]

    err = zeros(1, length(inner_angle));  % Preallocate

    % Calculate l2 based on current geometry
    term1 = (k/2 - m/2 - l1 * cos(gamma))^2;
    term2 = (h - l1 * sin(gamma))^2;
    l2 = sqrt(term1 + term2);

    for i = 1:length(inner_angle)
        ia = inner_angle(i);

        % Define nonlinear function to solve for 's'
        fun = @(s) -atan(h / (k/2 - m/2 + s)) - ...
            acos(safe_acos_arg((l1^2 + h^2 + (k/2 - m/2 + s).^2 - l2^2) / ...
            (2 * l1 * sqrt(h^2 + (k/2 - m/2 + s).^2)))) + gamma - ia;

        try
            s = fsolve(fun, 100, optimset('Display','off'));

            % Reject if result is invalid
            if ~isreal(s) || isnan(s) || s < 0
                err(i) = 1e6;
                continue;
            end

        catch
            err(i) = 1e6;
            continue;
        end

        % Compute outer angle from geometry
        A2 = (k/2 - m/2 - s);
        B2 = sqrt(h^2 + A2^2);
        acos_term2 = safe_acos_arg((l1^2 + h^2 + A2^2 - l2^2) / (2 * l1 * B2));
        outer_angle = atan(h / A2) + acos(acos_term2) - gamma;

        % Ideal outer angle from Ackermann
        cot_outer = (W / L) + cot(ia);
        ideal_outer_angle = acot(cot_outer);

        % Store absolute error
        err(i) = (outer_angle - ideal_outer_angle).^2;

        % Optional debug print (uncomment if needed)
        % fprintf("Inner: %.2f deg, Outer error: %.6f rad\n", rad2deg(ia), err(i));
    end

    % Mean squared error
    err_sum = sqrt(mean(err));
end

% Helper to keep acos arguments safe
function val = safe_acos_arg(x)
    val = min(max(x, -1), 1);
end
